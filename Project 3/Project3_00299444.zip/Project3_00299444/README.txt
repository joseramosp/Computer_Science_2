* Jose Ramos
* Student ID: 00299444* CIS 252 - T-7847
* October 27 of 2019* Project 3 - Ranking Choice Voting
---------------------------* This project has as its purpose to create a ranked choice voting machine that meets the next requirements:

1- Voter - maintains a list of candidates in ranked order
2- Candidate (remember every candidate is also a voter) - a candidate must have a party and a platform which can be printed on request
	1- Voting Machine - a class that offers a menu to the user and calculates the election results
	2- voters can rank votes
	3- voters can view candidates
	4- voters can view candidates' party and platform
3- A voter indicates when they have complete voting
4- When all voters have voted, report the results - include detailed print outs of the process.
5- Use linked lists of any kind in a number of places in your program (lots of opportunities here)
6- NO ARRAYS only linked lists* The main of this project is in the "Main.java" file compile and run that file to see the output of the program.

NOTE: Few methods were added to the project but non of the requirement were affected. In each class I explain if a method was added and the reason of doing it.* In this project I learned more about how to work with LikedLists. It was challenging to me how to use a list in a method and not affect it or the algorithm implemented on the method. Also another difficulty was to pass a value "no by reference" to another list. I understood that I had to clone some value and pass it to where I wanted to add it.* Citations: None.