5a. What is the time cost for a push on the array based century stack?

It has a cost of "n" when the array is size reached 100. Otherwise, it is 1.

5b. What is the time cost for a push on the linked based stack?

It has a cost of "n" when the array is size reached 100. Otherwise, it is 1.